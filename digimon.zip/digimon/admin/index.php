<?php
if (isset($_GET['page'])) {
    switch ($_GET['page']) {
        case 'home':
            require('page-home.php');
            break;
        case 'fat':
            require('page-fat.php');
            break;
        case 'inputfat':
            require('page-inputfat.php');
            break;
        case 'performanceteam':
            require('page-performanceteam.php');
            break;
        case 'log':
            require('page-log.php');
            break;
        case 'perubahantappingfat':
            require('page-perubahantappingfat.php');
            break;
        case 'updowngrade':
            require('page-updowngrade.php');
            break;
        case 'dismantle':
            require('page-dismantle.php');
            break;
        case 'enddevice':
            require('page-enddevice.php');
            break;
        case 'confirmtikor':
            require('page-confirmtikor.php');
            break;
        case 'akunmanager':
            require('page-akunmanager.php');
            break;
        case 'menumanager':
            require('page-menumanager.php');
            break;
        case 'fatmanager':
            require('page-fatmanager.php');
            break;
        default:
            require('page-home.php');
            break;
    }
} else {
    require('page-home.php');
}
