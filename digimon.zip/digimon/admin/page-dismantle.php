<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php
    require('../required/header-admin.php');
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Lapor Perubahan Data : Dismantle</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-file mr-1"></i>
                    Form
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <form action="#" method="post" id="formDismantle">
                      <div class="row">
                        <div class="col-12">
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="noDeak">No Deak :</label>
                                <input type="text" name="nodeak" id="noDeak" class="form-control form-control" placeholder="PD/XXX/XXX..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="sid">SID :</label>
                                <input type="text" name="sid" id="sid" class="form-control form-control" placeholder="0xxxxxx..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="alamat">Alamat :</label>
                                <input type="text" name="alamat" id="alamat" class="form-control form-control" placeholder="Input alamat user..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="tim">Tim :</label>
                                <select name="tim" id="tim" class="custom-select">
                                  <optgroup label="Pilih Tim">
                                    <?php
                                    $query_showtim4 = mysqli_query($connect, "SELECT * FROM master_tim ORDER BY nama_tim ASC");
                                    while ($data = mysqli_fetch_array($query_showtim4)) {
                                    ?>
                                      <option value="<?= $data['nama_tim'] ?>"><?= $data['nama_tim'] ?></option>
                                    <?php
                                    }
                                    ?>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="toggleOnt">
                                <label class="form-check-label" for="toggleOnt">ONT</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="toggleStb">
                                <label class="form-check-label" for="toggleStb">STB</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="toggleCable">
                                <label class="form-check-label" for="toggleCable">Cable</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="formOnt">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-signal mr-1"></i>
                    ONT
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOnt">SN ONT :</label>
                              <input type="text" name="snont" id="snOnt" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOnt">MAC ONT :</label>
                              <input type="text" name="macont" id="macOnt" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col-6">
                            <div class="form-group">
                              <label for="service">Service :</label>
                              <select name="service" id="service" class="custom-select">
                                <optgroup label="Pilih">
                                  <option value="STROOMNET 10Mbps">STROOMNET 10Mbps</option>
                                  <option value="STROOMNET 20Mbps">STROOMNET 20Mbps</option>
                                </optgroup>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="formStb">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-signal mr-1"></i>
                    STB
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snStb">SN STB :</label>
                              <input type="text" name="snstb" id="snStb" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macStb">MAC STB :</label>
                              <input type="text" name="macstb" id="macStb" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col-6">
                            <div class="form-group">
                              <label for="serviceIptv">Service IPTV :</label>
                              <select name="serviceiptv" id="serviceIptv" class="custom-select">
                                <optgroup label="Pilih">
                                  <option value="Transvision">IPTV Transvision</option>
                                  <option value="MNC 75 Channel">IPTV MNC 75 Channel</option>
                                </optgroup>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="formCable">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-plug mr-1"></i>
                    Cable
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="jenisCable">Jenis Cable :</label>
                              <select name="jeniscable" id="jenisCable" class="custom-select">
                                <optgroup label="Pilih">
                                  <option value="DropCorr">DropCorr</option>
                                  <option value="PreCon">PreCon</option>
                                </optgroup>
                              </select>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="panjangCable">Panjang Cable (m) :</label>
                              <input type="number" name="panjangcable" id="panjangCable" class="form-control form-control" min="0" required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col-6">
                            <div class="form-group">
                              <label for="jumlahPatchcord">Jumlah Patchcord/PigTail (u) :</label>
                              <input type="number" name="jumlahpatchcord" id="jumlahPatchcord" class="form-control form-control" min="0" required>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="submitForm">
            <!-- Left col -->
            <section class="col-lg-2">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-12">
                      <button type="submit" name="submit" class="btn btn-block btn-primary">SUBMIT</button>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php
    require('../required/footer.php');
    ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../assets/page-system/dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../assets/page-system/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
  <!-- Toggler -->
  <script>
    $(document).ready(function() {
      $("#formOnt").hide();
      $("#formStb").hide();
      $("#formCable").hide();
      $('#toggleOnt').click(function() {
        if ($(this).is(':checked')) {
          $("#formOnt").show(500);
        } else {
          $("#formOnt").hide(500);
        }
      });
      $('#toggleStb').click(function() {
        if ($(this).is(':checked')) {
          $("#formStb").show(500);
        } else {
          $("#formStb").hide(500);
        }
      });
      $('#toggleCable').click(function() {
        if ($(this).is(':checked')) {
          $("#formCable").show(500);
        } else {
          $("#formCable").hide(500);
        }
      });
    });
  </script>
</body>

</html>