<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php
    require('../required/header-admin.php');
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Data Performance Team</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-4">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-list mr-1"></i>
                    Pilih Team
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="form-row">
                      <div class="col">
                        <select id="team" class="custom-select">
                          <option selected disabled>---PILIH---</option>
                          <?php
                          $query_showtim = mysqli_query($connect, "SELECT * FROM master_tim ORDER BY nama_tim ASC");
                          while ($data = mysqli_fetch_array($query_showtim)) {
                          ?>
                            <option value="<?= $data['nama_tim'] ?>"><?= $data['nama_tim'] ?></option>
                          <?php
                          }
                          ?>
                        </select>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="internalAktivasistroomnet">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Performance Team Internal Aktivasi Stroomnet
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="teamInternalaktivasistroomnet" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Last Update</th>
                        <th>Status</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Last Update</th>
                        <th>Status</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>ini sid</td>
                          <td>ini alamat</td>
                          <td>ini last update</td>
                          <td>ini status</td>
                          <td>
                            <button type="button" data-toggle="modal" data-target="#modalDetail" class="btn btn-sm btn-primary"><i class="fas fa-eye"></i> Details</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="internalHarstroomnet">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Performance Team Internal HAR Stroomnet
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="teamInternalharstroomnet" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Last Update</th>
                        <th>Status</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Last Update</th>
                        <th>Status</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>ini sid</td>
                          <td>ini alamat</td>
                          <td>ini last update</td>
                          <td>ini status</td>
                          <td>
                            <button type="button" data-toggle="modal" data-target="#modalDetail" class="btn btn-sm btn-primary"><i class="fas fa-eye"></i> Details</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>

    <?php
    require('../required/footer.php');
    ?>

    <!-- Modal -->
    <div class="modal fade" id="modalDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
      <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Detail</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="container-fluid">
              <div class="row">
                <div class="col-12">
                </div>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../assets/page-system/dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../assets/page-system/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
  <!-- DataTables & Plugins -->
  <script src="../assets/page-system/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/jszip/jszip.min.js"></script>
  <script src="../assets/page-system/plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../assets/page-system/plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <script>
    $(function() {
      $("#teamInternalaktivasistroomnet").DataTable({
        "responsive": true,
        "autoWidth": false
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    $(function() {
      $("#teamInternalharstroomnet").DataTable({
        "responsive": true,
        "autoWidth": false
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });
  </script>
  <!-- Toggler -->
  <script>
    $(document).ready(function() {
      $("#internalAktivasistroomnet").hide();
      $("#internalHarstroomnet").hide();
      $('#team').on('change', function() {
        if (this.value == 'INTERNAL AKTIVASI STROOMNET') {
          $("#internalAktivasistroomnet").show(500);
        } else {
          $("#internalAktivasistroomnet").hide(500);
        }
        if (this.value == 'INTERNAL HAR STROOMNET') {
          $("#internalHarstroomnet").show(500);
        } else {
          $("#internalHarstroomnet").hide(500);
        }
      });
    });
  </script>
</body>

</html>