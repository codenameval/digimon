<?php
session_start();
if (isset($_SESSION['status'])) {
    if ($_SESSION['status'] == "loggedin") {
        require "../koneksi/conn.php";
        if ($_SESSION['role'] != "admin") {
            if ($_SESSION['role'] == "user") {
                header("location:../user/index.php");
            } else if ($_SESSION['role'] == "cc") {
                header("location:../cc/index.php");
            } else {
                header("location:../index.php?info=unidentified");
            }
        }
    } else {
        header("location:../index.php?info=notlogin");
    }
} else {
    header("location:../index.php?info=notlogin");
}
if (isset($_POST['account_add'])) {
    $nama = mysqli_real_escape_string($connect, $_POST['nama']);
    $bidang = mysqli_real_escape_string($connect, $_POST['bidang']);
    $role = mysqli_real_escape_string($connect, $_POST['role']);
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);
    $check = mysqli_query($connect, "SELECT id FROM account WHERE BINARY username='$username'");
    if (mysqli_num_rows($check) > 0) {
        echo "<script>alert('Username sudah digunakan!');history.go(-1);</script>";
    } else {
        $insert = mysqli_query($connect, "INSERT INTO account VALUES(NULL,'$nama','$bidang','$role','$username','$password')");
        if ($insert) {
            echo "<script>alert('Akun berhasil ditambahkan!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal menambahkan Akun!');history.go(-1);</script>";
        }
    }
}
if (isset($_POST['account_delete'])) {
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $check = mysqli_query($connect, "SELECT id FROM account WHERE BINARY username='$username'");
    if (mysqli_num_rows($check) > 0) {
        $delete = mysqli_query($connect, "DELETE FROM account WHERE BINARY username='$username'");
        if ($delete) {
            echo "<script>alert('Akun berhasil Dihapus!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal menghapus Akun!');history.go(-1);</script>";
        }
    } else {
        echo "<script>alert('Akun tidak ditemukan!');history.go(-1);</script>";
    }
}
if (isset($_POST['account_update'])) {
    $nama = mysqli_real_escape_string($connect, $_POST['nama']);
    $bidang = mysqli_real_escape_string($connect, $_POST['bidang']);
    $role = mysqli_real_escape_string($connect, $_POST['role']);
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $username_old = mysqli_real_escape_string($connect, $_POST['username_old']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);
    $check = mysqli_query($connect, "SELECT id FROM account WHERE BINARY username='$username_old'");
    if (mysqli_num_rows($check) > 0) {
        $update = mysqli_query($connect, "UPDATE account SET nama='$nama', bidang='$bidang', role='$role', username='$username', password='$password' WHERE BINARY username='$username_old'");
        if ($update) {
            echo "<script>alert('Akun berhasil Diupdate!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal mengupdate informasi Akun!');history.go(-1);</script>";
        }
    } else {
        echo "<script>alert('Akun tidak ditemukan!');history.go(-1);</script>";
    }
}
if (isset($_POST['tim_add'])) {
    $tim = mysqli_real_escape_string($connect, $_POST['tim']);
    $check = mysqli_query($connect, "SELECT id FROM master_tim WHERE BINARY nama_tim='$tim'");
    if (mysqli_num_rows($check) > 0) {
        echo "<script>alert('Nama tim sudah digunakan!');history.go(-1);</script>";
    } else {
        $insert = mysqli_query($connect, "INSERT INTO master_tim VALUES(NULL,'$tim')");
        if ($insert) {
            echo "<script>alert('Tim berhasil ditambahkan!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal menambahkan Tim!');history.go(-1);</script>";
        }
    }
}
if (isset($_POST['tim_delete'])) {
    $tim = mysqli_real_escape_string($connect, $_POST['tim']);
    $check = mysqli_query($connect, "SELECT id FROM master_tim WHERE BINARY nama_tim='$tim'");
    if (mysqli_num_rows($check) > 0) {
        $delete = mysqli_query($connect, "DELETE FROM master_tim WHERE BINARY nama_tim='$tim'");
        if ($delete) {
            echo "<script>alert('Tim berhasil Dihapus!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal menghapus Tim!');history.go(-1);</script>";
        }
    } else {
        echo "<script>alert('Tim tidak ditemukan!');history.go(-1);</script>";
    }
}
if (isset($_POST['tim_update'])) {
    $tim = mysqli_real_escape_string($connect, $_POST['tim']);
    $tim_old = mysqli_real_escape_string($connect, $_POST['tim_old']);
    $check = mysqli_query($connect, "SELECT id FROM master_tim WHERE BINARY nama_tim='$tim_old'");
    if (mysqli_num_rows($check) > 0) {
        $update = mysqli_query($connect, "UPDATE master_tim SET nama_tim='$tim' WHERE BINARY nama_tim='$tim_old'");
        if ($update) {
            echo "<script>alert('Tim berhasil Diupdate!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal mengupdate informasi Tim!');history.go(-1);</script>";
        }
    } else {
        echo "<script>alert('Tim tidak ditemukan!');history.go(-1);</script>";
    }
}
if (isset($_POST['fat_add'])) {
    $idfat = mysqli_real_escape_string($connect, $_POST['idfat']);
    $idfdt = mysqli_real_escape_string($connect, $_POST['idfdt']);
    $olt = mysqli_real_escape_string($connect, $_POST['olt']);
    $zona = mysqli_real_escape_string($connect, $_POST['zona']);
    $perumahan = mysqli_real_escape_string($connect, $_POST['perumahan']);
    $tikorfdt = mysqli_real_escape_string($connect, $_POST['tikorfdt']);
    $tikorfat = mysqli_real_escape_string($connect, $_POST['tikorfat']);
    $kapasitas = mysqli_real_escape_string($connect, $_POST['kapasitas']);
    $check = mysqli_query($connect, "SELECT id FROM master_fat WHERE BINARY idfat='$idfat'");
    if (mysqli_num_rows($check) > 0) {
        echo "<script>alert('ID FAT sudah digunakan!');history.go(-1);</script>";
    } else {
        $insert = mysqli_query($connect, "INSERT INTO master_fat VALUES(NULL,'$idfat','$idfdt','$olt','$zona','$perumahan','$tikorfdt','$tikorfat','$kapasitas')");
        if ($insert) {
            echo "<script>alert('Data FAT berhasil ditambahkan!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal menambahkan Data FAT!');history.go(-1);</script>";
        }
    }
}
if (isset($_POST['fat_delete'])) {
    $idfat = mysqli_real_escape_string($connect, $_POST['idfat']);
    $check = mysqli_query($connect, "SELECT id FROM master_fat WHERE BINARY idfat='$idfat'");
    if (mysqli_num_rows($check) > 0) {
        $delete = mysqli_query($connect, "DELETE FROM master_fat WHERE BINARY idfat='$idfat'");
        if ($delete) {
            echo "<script>alert('Data FAT berhasil Dihapus!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal menghapus Data FAT!');history.go(-1);</script>";
        }
    } else {
        echo "<script>alert('Data FAT tidak ditemukan!');history.go(-1);</script>";
    }
}
if (isset($_POST['fat_update'])) {
    $idfat = mysqli_real_escape_string($connect, $_POST['idfat']);
    $idfat_old = mysqli_real_escape_string($connect, $_POST['idfat_old']);
    $idfdt = mysqli_real_escape_string($connect, $_POST['idfdt']);
    $olt = mysqli_real_escape_string($connect, $_POST['olt']);
    $zona = mysqli_real_escape_string($connect, $_POST['zona']);
    $perumahan = mysqli_real_escape_string($connect, $_POST['perumahan']);
    $tikorfdt = mysqli_real_escape_string($connect, $_POST['tikorfdt']);
    $tikorfat = mysqli_real_escape_string($connect, $_POST['tikorfat']);
    $kapasitas = mysqli_real_escape_string($connect, $_POST['kapasitas']);
    $check = mysqli_query($connect, "SELECT id FROM master_fat WHERE BINARY idfat='$idfat_old'");
    if (mysqli_num_rows($check) > 0) {
        $update = mysqli_query($connect, "UPDATE master_fat SET idfat='$idfat',idfdt='$idfdt',olt='$olt',zona='$zona',perumahan='$perumahan',tikorfdt='$tikorfdt',tikorfat='$tikorfat',kapasitas='$kapasitas' WHERE BINARY idfat='$idfat_old'");
        if ($update) {
            echo "<script>alert('Data FAT berhasil Diupdate!');history.go(-1);</script>";
        } else {
            echo "<script>alert('Gagal mengupdate Data FAT! ID FAT sudah digunakan...');history.go(-1);</script>";
        }
    } else {
        echo "<script>alert('Data FAT tidak ditemukan!');history.go(-1);</script>";
    }
}
