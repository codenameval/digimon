<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php
    require('../required/header-admin.php');
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Data FAT</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-search mr-1"></i>
                    Kolom Pencarian
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <form action="#" method="post">
                      <div class="form-row">
                        <div class="col">
                          <input type="number" name="sid" id="noSid" class="form-control form-control" placeholder="masukkan sid..." min="0">
                        </div>
                        <div class="col">
                          <input type="text" name="alamat" id="alamat" class="form-control form-control" placeholder="masukkan alamat...">
                        </div>
                        <div class="col">
                          <input type="text" name="idfat" id="idFat" class="form-control form-control" placeholder="masukkan id fat...">
                        </div>
                        <div class="col">
                          <input type="text" name="noso" id="noSo" class="form-control form-control" placeholder="masukkan nomor so...">
                        </div>
                      </div>
                      <br>
                      <div class="form-row">
                        <div class="col">
                          <input type="text" name="snont" id="snOnt" class="form-control form-control" placeholder="SN ONT...">
                        </div>
                        <div class="col">
                          <input type="text" name="snspd" id="snSpd" class="form-control form-control" placeholder="SN SPD...">
                        </div>
                        <div class="col">
                          <input type="text" name="nmuser" id="nmUser" class="form-control form-control" placeholder="nama user...">
                        </div>
                        <div class="col">
                          <input type="text" name="l3uplink" id="l3Uplink" class="form-control form-control" placeholder="L3/UPLINK OLT...">
                        </div>
                      </div>
                      <br>
                      <div class="form-row">
                        <div class="col-3">
                          <button type="submit" class=" btn btn-primary btn-block"><i class="fas fa-search"></i>Search</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-4">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-list mr-1"></i>
                    Pilih Zona
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="form-row">
                      <div class="col">
                        <select id="zona" class="custom-select">
                          <option selected disabled>---PILIH---</option>
                          <option value="JAKARTA">JAKARTA</option>
                          <option value="BOGOR">BOGOR</option>
                          <option value="DEPOK">DEPOK</option>
                          <option value="TANGERANG">TANGERANG</option>
                          <option value="BEKASI">BEKASI</option>
                          <option value="BANTEN">BANTEN</option>
                          <option value="KEPULAUAN SERIBU">KEPULAUAN SERIBU</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatJakarta">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona JAKARTA
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableZona" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Griya Indah</td>
                          <td>100</td>
                          <td>10</td>
                          <td>3</td>
                          <td><a href="#" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Utilitas</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatBogor">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona BOGOR
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableZona" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Griya Indah</td>
                          <td>100</td>
                          <td>10</td>
                          <td>3</td>
                          <td><a href="#" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Utilitas</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatDepok">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona DEPOK
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableZona" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Griya Indah</td>
                          <td>100</td>
                          <td>10</td>
                          <td>3</td>
                          <td><a href="#" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Utilitas</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatTangerang">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona TANGERANG
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableZona" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Griya Indah</td>
                          <td>100</td>
                          <td>10</td>
                          <td>3</td>
                          <td><a href="#" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Utilitas</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatBekasi">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona BEKASI
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableZona" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Griya Indah</td>
                          <td>100</td>
                          <td>10</td>
                          <td>3</td>
                          <td><a href="#" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Utilitas</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatBanten">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona BANTEN
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableZona" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>Perumahan / Kampung</th>
                        <th>Jumlah User</th>
                        <th>Jumlah FAT</th>
                        <th>Jumlah Dismantle</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Griya Indah</td>
                          <td>100</td>
                          <td>10</td>
                          <td>3</td>
                          <td><a href="#" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View Utilitas</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="fatKepseribu">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-archive mr-1"></i>
                    List Data FAT by Zona KEPULAUAN SERIBU
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <h1 class="text-center">NGAREPP !!!</h1>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php
    require('../required/footer.php');
    ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../assets/page-system/dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../assets/page-system/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
  <!-- DataTables & Plugins -->
  <script src="../assets/page-system/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/jszip/jszip.min.js"></script>
  <script src="../assets/page-system/plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../assets/page-system/plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <script>
    $(function() {
      $("#tableZona").DataTable({
        "responsive": true,
        "autoWidth": false,
        "buttons": ["excel", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });
  </script>
  <!-- Toggler -->
  <script>
    $(document).ready(function() {
      $("#fatJakarta").hide();
      $("#fatBogor").hide();
      $("#fatDepok").hide();
      $("#fatTangerang").hide();
      $("#fatBekasi").hide();
      $("#fatBanten").hide();
      $("#fatKepseribu").hide();
      $('#zona').on('change', function() {
        if (this.value == 'JAKARTA') {
          $("#fatJakarta").show(500);
        } else {
          $("#fatJakarta").hide(500);
        }
        if (this.value == 'BOGOR') {
          $("#fatBogor").show(500);
        } else {
          $("#fatBogor").hide(500);
        }
        if (this.value == 'DEPOK') {
          $("#fatDepok").show(500);
        } else {
          $("#fatDepok").hide(500);
        }
        if (this.value == 'TANGERANG') {
          $("#fatTangerang").show(500);
        } else {
          $("#fatTangerang").hide(500);
        }
        if (this.value == 'BEKASI') {
          $("#fatBekasi").show(500);
        } else {
          $("#fatBekasi").hide(500);
        }
        if (this.value == 'BANTEN') {
          $("#fatBanten").show(500);
        } else {
          $("#fatBanten").hide(500);
        }
        if (this.value == 'KEPULAUAN SERIBU') {
          $("#fatKepseribu").show(500);
        } else {
          $("#fatKepseribu").hide(500);
        }
      });
    });
  </script>
</body>

</html>