<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- summernote -->
    <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <?php
        require('../required/header-admin.php');
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Input Data FAT</h1>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Left col -->
                        <section class="col-lg-12">
                            <!-- Custom tabs (Charts with tabs)-->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-file mr-1"></i>
                                        Form
                                    </h3>
                                </div><!-- /.card-header -->
                                <div class="card-body">
                                    <div class="tab-content p-0">
                                        <form action="#" method="post">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-row">
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="nmUser">Nama User :</label>
                                                                <input type="text" name="nmuser" id="nmUser" class="form-control" placeholder="Nama User..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="sid">SID :</label>
                                                                <input type="text" name="sid" id="sid" class="form-control" placeholder="SID..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="service">Service :</label>
                                                                <select name="service" id="service" class="custom-select" required>
                                                                    <optgroup label="---Pilih---">
                                                                        <option value="Stroomnet">Stroomnet</option>
                                                                        <option value="Stroomnet Biz">Stroomnet Biz
                                                                        </option>
                                                                        <option value="IPVPN">IPVPN</option>
                                                                        <option value="Metronet">Metronet</option>
                                                                        <option value="Metro QinQ">Metor QinQ</option>
                                                                        <option value="Inet Broadband Corporate">Inet
                                                                            Broadband Corporate</option>
                                                                        <option value="Internet Corporate">Internet
                                                                            Corporate</option>
                                                                        <option value="Clear Channel">Clear Channel
                                                                        </option>
                                                                        <option value="IIX">IIX</option>
                                                                        <option value="IX">IX</option>
                                                                        <option value="IP Transit">IP Transit</option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="bw">Bandwidth :</label>
                                                                <input type="number" name="bw" id="bw" class="form-control" min="0" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="satuan">Satuan :</label>
                                                                <select name="satuan" id="satuan" class="custom-select" required>
                                                                    <optgroup label="---Pilih---">
                                                                        <option value="Gbps">Gbps</option>
                                                                        <option value="Mbps">Mbps
                                                                        </option>
                                                                        <option value="Kbps">Kbps
                                                                        </option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="serviceIptv">Service IPTV :</label>
                                                                <select name="serviceiptv" id="serviceIptv" class="custom-select" required>
                                                                    <optgroup label="---Pilih---">
                                                                        <option value="MNC">MNC</option>
                                                                        <option value="Transvision">Transvision
                                                                        </option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="alamat">Alamat :</label>
                                                                <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Alamat..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="snont">SN ONT :</label>
                                                                <input type="text" name="snont" id="snont" class="form-control" placeholder="SN ONT..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="snstb">SN STB :</label>
                                                                <input type="text" name="snstb" id="snstb" class="form-control" placeholder="SN STB..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="transmitoutput">Transmit Output :</label>
                                                                <input type="text" name="transmitoutput" id="transmitoutput" class="form-control" placeholder="Transmit Output..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="idfat">ID FAT :</label>
                                                                <input type="text" name="idfat" id="idfat" class="form-control" placeholder="ID FAT..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="port">Port :</label>
                                                                <input type="number" name="port" id="port" class="form-control" placeholder="Port..." min="0" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="portonuid">PORT & ONUID :</label>
                                                                <input type="text" name="portonuid" id="portonuid" class="form-control" placeholder="Port&OnUid..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="noso">NO SO :</label>
                                                                <input type="text" name="noso" id="noso" class="form-control" placeholder="No SO..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="tim">TIM :</label>
                                                                <select id="team" name="tim" class="custom-select">
                                                                    <option selected disabled>---PILIH---</option>
                                                                    <?php
                                                                    $query_showtim = mysqli_query($connect, "SELECT * FROM master_tim ORDER BY nama_tim ASC");
                                                                    while ($data = mysqli_fetch_array($query_showtim)) {
                                                                    ?>
                                                                        <option value="<?= $data['nama_tim'] ?>"><?= $data['nama_tim'] ?></option>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="material">Material :</label>
                                                                <select name="material" id="material" class="custom-select" required>
                                                                    <optgroup label="---Pilih---">
                                                                        <option value="Precon">Precon</option>
                                                                        <option value="DW">DW
                                                                        </option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="meter">Meter :</label>
                                                                <input type="number" name="meter" id="meter" class="form-control" placeholder="Meter..." min="0" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="ptl">PTL :</label>
                                                                <select name="ptl" id="ptl" class="custom-select" required>
                                                                    <optgroup label="---Pilih---">
                                                                        <option value="Mohammad Syahrur">Mohammad
                                                                            Syahrur Ramadhan</option>
                                                                        <option value="Rifki Nur Huda">Muhammad Rifki
                                                                            Nurhuda
                                                                        </option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="status">Status :</label>
                                                                <select name="status" id="status" class="custom-select" required>
                                                                    <optgroup label="---Pilih---">
                                                                        <option value="Selesai">Selesai</option>
                                                                        <option value="On Progress">On Progress
                                                                        </option>
                                                                        <option value="Corporate">Corporate</option>
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="tikoruser">Tikor User :</label>
                                                                <input type="text" name="tikoruser" id="tikoruser" class="form-control" placeholder="Tikor User..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="barcode">Barcode :</label>
                                                                <input type="text" name="barcode" id="barcode" class="form-control" placeholder="Barcode..." required>
                                                            </div>
                                                        </div>
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <label for="note">Note :</label>
                                                                <textarea name="note" id="note" cols="30" rows="3" class="form-control" placeholder="Note..."></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col-4">
                                                            <div class="form-group">
                                                                <button type="submit" class="btn btn-primary btn-block">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div><!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </section>
                        <!-- /.Left col -->
                    </div>
                    <!-- /.row (main row) -->
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <?php
        require('../required/footer.php');
        ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../assets/page-system/dist/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../assets/page-system/dist/js/demo.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
</body>

</html>