<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php
    require('../required/header-admin.php');
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Lapor Perubahan Data : Tapping FAT</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-4">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-list mr-1"></i>
                    Pilih Status
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="form-row">
                      <div class="col">
                        <select id="status" class="custom-select">
                          <option selected disabled>---PILIH---</option>
                          <option value="AKTIVASI">AKTIVASI (Provisioning)</option>
                          <option value="GANGGUAN">GANGGUAN (Maintenance)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="aktivasi">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-poo-storm mr-1"></i>
                    AKTIVASI
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <form action="#" method="post">
                      <div class="row">
                        <div class="col-6">
                          <div class="form-group">
                            <label for="noSo">Nomor SO :</label>
                            <input type="text" name="noso" id="noSo" class="form-control form-control" placeholder="SPA/ACT/2111/000212/TER..." required>
                          </div>
                          <div class="form-group">
                            <label for="sid">Nomor SID :</label>
                            <input type="number" name="sid" id="sid" class="form-control form-control" placeholder="000333..." min="0" required>
                          </div>
                          <div class="form-group">
                            <label for="alamat">Alamat :</label>
                            <input type="text" name="alamat" id="alamat" class="form-control form-control" placeholder="Jalan Duren Tiga..." required>
                          </div>
                          <div class="form-group">
                            <label for="tim">Tim :</label>
                            <select name="tim" id="tim" class="custom-select">
                              <optgroup label="Pilih Tim">
                                <option value="Internal HAR Stroomnet">Internal HAR Stroomnet</option>
                                <option value="Internal AKV Stroomnet">Internal AKV Stroomnet</option>
                                <option value="FAMIKA">FAMIKA</option>
                              </optgroup>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="olt">OLT :</label>
                            <input type="text" name="olt" id="olt" class="form-control" placeholder="OLT..." required>
                          </div>
                          <div class="form-group">
                            <label for="uplink">UpLink :</label>
                            <input type="text" name="uplink" id="uplink" class="form-control" placeholder="UpLink..." required>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="idFatlama">ID FAT Lama :</label>
                                <input type="text" name="idfatlama" id="idFatlama" class="form-control form-control" placeholder="CKGA00..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="portFatlama">Port :</label>
                                <select name="portfatlama" id="portFatlama" class="custom-select">
                                  <optgroup label="Pilih">
                                    <option value="1">1</option>
                                    <option value="8">8</option>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="idFatbaru">ID FAT Baru :</label>
                                <input type="text" name="idfatbaru" id="idFatbaru" class="form-control form-control" placeholder="CKGA00..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="portFatbaru">Port :</label>
                                <select name="portfatbaru" id="portFatbaru" class="custom-select">
                                  <optgroup label="Pilih">
                                    <option value="1">1</option>
                                    <option value="8">8</option>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="tikorFatlama">Tikor FAT Lama :</label>
                            <input type="text" name="tikorfatlama" id="tikorFatlama" class="form-control form-control" placeholder="-6.xxxx, 106.xxxx..." required>
                          </div>
                          <div class="form-group">
                            <label for="tikorFatbaru">Tikor FAT Baru :</label>
                            <input type="text" name="tikorfatbaru" id="tikorFatbaru" class="form-control form-control" placeholder="-6.xxxx, 106.xxxx..." required>
                          </div>
                          <div class="form-group">
                            <label for="pop">POP :</label>
                            <input type="text" name="pop" id="pop" class="form-control" placeholder="POP..." required>
                          </div>
                          <div class="form-group">
                            <label for="portonuid">PORT & ONUID :</label>
                            <input type="text" name="portonuid" id="portonuid" class="form-control" placeholder="Port&OnUid..." required>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                          <div class="form-group">
                            <label for="note">Note :</label>
                            <textarea name="note" id="note" cols="30" rows="5" class="form-control" placeholder="Alasan perubahan tapping..."></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-2">
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">SUBMIT</button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="gangguan">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-wrench mr-1"></i>
                    GANGGUAN
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <form action="#" method="post">
                      <div class="row">
                        <div class="col-6">
                          <div class="form-group">
                            <label for="noTiket">Nomor Tiket :</label>
                            <input type="text" name="notiket" id="noTiket" class="form-control form-control" placeholder="NO/TIK/XXX/XXX..." required>
                          </div>
                          <div class="form-group">
                            <label for="sid">Nomor SID :</label>
                            <input type="number" name="sid" id="sid" class="form-control form-control" placeholder="000333..." min="0" required>
                          </div>
                          <div class="form-group">
                            <label for="alamat">Alamat :</label>
                            <input type="text" name="alamat" id="alamat" class="form-control form-control" placeholder="Jalan Duren Tiga..." required>
                          </div>
                          <div class="form-group">
                            <label for="tim">Tim :</label>
                            <select name="tim" id="tim" class="custom-select">
                              <optgroup label="Pilih Tim">
                                <option value="Internal HAR Stroomnet">Internal HAR Stroomnet</option>
                                <option value="Internal AKV Stroomnet">Internal AKV Stroomnet</option>
                                <option value="FAMIKA">FAMIKA</option>
                              </optgroup>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="olt">OLT :</label>
                            <input type="text" name="olt" id="olt" class="form-control" placeholder="OLT..." required>
                          </div>
                          <div class="form-group">
                            <label for="uplink">UpLink :</label>
                            <input type="text" name="uplink" id="uplink" class="form-control" placeholder="UpLink..." required>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="idFatlama">ID FAT Lama :</label>
                                <input type="text" name="idfatlama" id="idFatlama" class="form-control form-control" placeholder="CKGA00..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="portFatlama">Port :</label>
                                <select name="portfatlama" id="portFatlama" class="custom-select">
                                  <optgroup label="Pilih">
                                    <option value="1">1</option>
                                    <option value="8">8</option>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="idFatbaru">ID FAT Baru :</label>
                                <input type="text" name="idfatbaru" id="idFatbaru" class="form-control form-control" placeholder="CKGA00..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="portFatbaru">Port :</label>
                                <select name="portfatbaru" id="portFatbaru" class="custom-select">
                                  <optgroup label="Pilih">
                                    <option value="1">1</option>
                                    <option value="8">8</option>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="tikorFatlama">Tikor FAT Lama :</label>
                            <input type="text" name="tikorfatlama" id="tikorFatlama" class="form-control form-control" placeholder="-6.xxxx, 106.xxxx..." required>
                          </div>
                          <div class="form-group">
                            <label for="tikorFatbaru">Tikor FAT Baru :</label>
                            <input type="text" name="tikorfatbaru" id="tikorFatbaru" class="form-control form-control" placeholder="-6.xxxx, 106.xxxx..." required>
                          </div>
                          <div class="form-group">
                            <label for="pop">POP :</label>
                            <input type="text" name="pop" id="pop" class="form-control" placeholder="POP..." required>
                          </div>
                          <div class="form-group">
                            <label for="portonuid">PORT & ONUID :</label>
                            <input type="text" name="portonuid" id="portonuid" class="form-control" placeholder="Port&OnUid..." required>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                          <div class="form-group">
                            <label for="note">Note :</label>
                            <textarea name="note" id="note" cols="30" rows="5" class="form-control" placeholder="Alasan perubahan tapping..."></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-2">
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block">SUBMIT</button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php
    require('../required/footer.php');
    ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../assets/page-system/dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../assets/page-system/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
  <!-- Toggler -->
  <script>
    $(document).ready(function() {
      $("#aktivasi").hide();
      $("#gangguan").hide();
      $('#status').on('change', function() {
        if (this.value == 'AKTIVASI') {
          $("#aktivasi").show(500);
        } else {
          $("#aktivasi").hide(500);
        }
        if (this.value == 'GANGGUAN') {
          $("#gangguan").show(500);
        } else {
          $("#gangguan").hide(500);
        }
      });
    });
  </script>
</body>

</html>