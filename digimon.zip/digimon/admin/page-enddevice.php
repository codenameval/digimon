<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php
    require('../required/header-admin.php');
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Lapor Perubahan Data : End Device</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-4">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-list mr-1"></i>
                    Pilih Status
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="form-row">
                      <div class="col">
                        <select id="status" class="custom-select">
                          <option selected disabled>---PILIH---</option>
                          <option value="AKTIVASI">AKTIVASI (Provisioning)</option>
                          <option value="GANGGUAN">GANGGUAN (Maintenance)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="aktivasi">
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-file mr-1"></i>
                    Form
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <form action="#" method="post" id="formDismantle">
                      <div class="row">
                        <div class="col-12">
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="noSo">No SO :</label>
                                <input type="text" name="noso" id="noSo" class="form-control form-control" placeholder="SPA/XXX/XXX..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="sid">SID :</label>
                                <input type="text" name="sid" id="sid" class="form-control form-control" placeholder="0xxxxxx..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="alamat">Alamat :</label>
                                <input type="text" name="alamat" id="alamat" class="form-control form-control" placeholder="Input alamat user..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="tim">Tim :</label>
                                <select name="tim" id="tim" class="custom-select">
                                  <optgroup label="Pilih Tim">
                                    <?php
                                    $query_showtim1 = mysqli_query($connect, "SELECT * FROM master_tim ORDER BY nama_tim ASC");
                                    while ($data = mysqli_fetch_array($query_showtim1)) {
                                    ?>
                                      <option value="<?= $data['nama_tim'] ?>"><?= $data['nama_tim'] ?></option>
                                    <?php
                                    }
                                    ?>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="olt">OLT :</label>
                                <input type="text" name="olt" id="olt" class="form-control" placeholder="OLT..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="pop">POP :</label>
                                <input type="text" name="pop" id="pop" class="form-control" placeholder="POP..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="uplink">UpLink :</label>
                                <input type="text" name="uplink" id="uplink" class="form-control" placeholder="UpLink..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="portonuid">PORT & ONUID :</label>
                                <input type="text" name="portonuid" id="portonuid" class="form-control" placeholder="Port&OnUid..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="aktivasitoggleOnt">
                                <label class="form-check-label" for="toggleOnt">ONT</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="aktivasitoggleStb">
                                <label class="form-check-label" for="toggleStb">STB</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
          </div>
          <div class="row" id="gangguan">
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-file mr-1"></i>
                    Form
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <form action="#" method="post" id="formDismantle">
                      <div class="row">
                        <div class="col-12">
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="noTiket">No Tiket :</label>
                                <input type="text" name="notiket" id="noTiket" class="form-control form-control" placeholder="TIK/XXX/XXX..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="sid">SID :</label>
                                <input type="text" name="sid" id="sid" class="form-control form-control" placeholder="0xxxxxx..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="alamat">Alamat :</label>
                                <input type="text" name="alamat" id="alamat" class="form-control form-control" placeholder="Input alamat user..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="tim">Tim :</label>
                                <select name="tim" id="tim" class="custom-select">
                                  <optgroup label="Pilih Tim">
                                    <?php
                                    $query_showtim2 = mysqli_query($connect, "SELECT * FROM master_tim ORDER BY nama_tim ASC");
                                    while ($data = mysqli_fetch_array($query_showtim2)) {
                                    ?>
                                      <option value="<?= $data['nama_tim'] ?>"><?= $data['nama_tim'] ?></option>
                                    <?php
                                    }
                                    ?>
                                  </optgroup>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="olt">OLT :</label>
                                <input type="text" name="olt" id="olt" class="form-control" placeholder="OLT..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="pop">POP :</label>
                                <input type="text" name="pop" id="pop" class="form-control" placeholder="POP..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-group">
                                <label for="uplink">UpLink :</label>
                                <input type="text" name="uplink" id="uplink" class="form-control" placeholder="UpLink..." required>
                              </div>
                            </div>
                            <div class="col">
                              <div class="form-group">
                                <label for="portonuid">PORT & ONUID :</label>
                                <input type="text" name="portonuid" id="portonuid" class="form-control" placeholder="Port&OnUid..." required>
                              </div>
                            </div>
                          </div>
                          <div class="form-row">
                            <div class="col">
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="gangguantoggleOnt">
                                <label class="form-check-label" for="toggleOnt">ONT</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="gangguantoggleStb">
                                <label class="form-check-label" for="toggleStb">STB</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
          </div>
          <div class="row" id="aktivasiformOnt">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-signal mr-1"></i>
                    ONT
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntlama">SN ONT Lama :</label>
                              <input type="text" name="snontlama" id="snOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntlama">MAC ONT Lama :</label>
                              <input type="text" name="macontlama" id="macOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntbaru">SN ONT Baru :</label>
                              <input type="text" name="snontbaru" id="snOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntbaru">MAC ONT Baru :</label>
                              <input type="text" name="macontbaru" id="macOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="aktivasiformStb">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-signal mr-1"></i>
                    STB
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntlama">SN ONT Lama :</label>
                              <input type="text" name="snontlama" id="snOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntlama">MAC ONT Lama :</label>
                              <input type="text" name="macontlama" id="macOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntbaru">SN ONT Baru :</label>
                              <input type="text" name="snontbaru" id="snOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntbaru">MAC ONT Baru :</label>
                              <input type="text" name="macontbaru" id="macOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="aktivasisubmitForm">
            <!-- Left col -->
            <section class="col-lg-2">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-12">
                      <button type="submit" name="submit" class="btn btn-block btn-primary">SUBMIT</button>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="gangguanformOnt">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-signal mr-1"></i>
                    ONT
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntlama">SN ONT Lama :</label>
                              <input type="text" name="snontlama" id="snOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntlama">MAC ONT Lama :</label>
                              <input type="text" name="macontlama" id="macOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntbaru">SN ONT Baru :</label>
                              <input type="text" name="snontbaru" id="snOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntbaru">MAC ONT Baru :</label>
                              <input type="text" name="macontbaru" id="macOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="gangguanformStb">
            <!-- Left col -->
            <section class="col-lg-12">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-signal mr-1"></i>
                    STB
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <div class="row">
                      <div class="col-12">
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntlama">SN ONT Lama :</label>
                              <input type="text" name="snontlama" id="snOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntlama">MAC ONT Lama :</label>
                              <input type="text" name="macontlama" id="macOntlama" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col">
                            <div class="form-group">
                              <label for="snOntbaru">SN ONT Baru :</label>
                              <input type="text" name="snontbaru" id="snOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                          <div class="col">
                            <div class="form-group">
                              <label for="macOntbaru">MAC ONT Baru :</label>
                              <input type="text" name="macontbaru" id="macOntbaru" class="form-control form-control" placeholder="HURUF BESAR SEMUA..." required>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <div class="row" id="gangguansubmitForm">
            <!-- Left col -->
            <section class="col-lg-2">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-12">
                      <button type="submit" name="submit" class="btn btn-block btn-primary">SUBMIT</button>
                    </div>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php
    require('../required/footer.php');
    ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../assets/page-system/dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../assets/page-system/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
  <!-- Toggler -->
  <script>
    $(document).ready(function() {
      $("#aktivasi").hide();
      $("#gangguan").hide();
      $("#aktivasisubmitForm").hide();
      $("#gangguansubmitForm").hide();
      $('#status').on('change', function() {
        if (this.value == 'AKTIVASI') {
          $("#aktivasi").show(500);
          $("#aktivasisubmitForm").show(500);
        } else {
          $("#aktivasi").hide(500);
          $("#aktivasisubmitForm").hide(500);
          $("#aktivasiformOnt").hide();
          $("#aktivasiformStb").hide();
          $("#gangguanformOnt").hide();
          $("#gangguanformStb").hide();
        }
        if (this.value == 'GANGGUAN') {
          $("#gangguan").show(500);
          $("#gangguansubmitForm").show(500);
        } else {
          $("#gangguan").hide(500);
          $("#gangguansubmitForm").hide(500);
          $("#aktivasiformOnt").hide();
          $("#aktivasiformStb").hide();
          $("#gangguanformOnt").hide();
          $("#gangguanformStb").hide();
        }
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      $("#aktivasiformOnt").hide();
      $("#aktivasiformStb").hide();
      $("#gangguanformOnt").hide();
      $("#gangguanformStb").hide();
      $('#aktivasitoggleOnt').click(function() {
        if ($(this).is(':checked')) {
          $("#aktivasiformOnt").show(500);
        } else {
          $("#aktivasiformOnt").hide(500);
        }
      });
      $('#aktivasitoggleStb').click(function() {
        if ($(this).is(':checked')) {
          $("#aktivasiformStb").show(500);
        } else {
          $("#aktivasiformStb").hide(500);
        }
      });
      $('#gangguantoggleOnt').click(function() {
        if ($(this).is(':checked')) {
          $("#gangguanformOnt").show(500);
        } else {
          $("#gangguanformOnt").hide(500);
        }
      });
      $('#gangguantoggleStb').click(function() {
        if ($(this).is(':checked')) {
          $("#gangguanformStb").show(500);
        } else {
          $("#gangguanformStb").hide(500);
        }
      });
    });
  </script>
</body>

</html>