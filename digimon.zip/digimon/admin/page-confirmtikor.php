<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/page-system/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php
    require('../required/header-admin.php');
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Konfirmasi Tikor User</h1>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-6">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-clock mr-1"></i>
                    On Proses
                  </h3>
                  <div class="d-flex justify-content-end">
                  </div>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableProses" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>No SO</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Tikor User Salah</th>
                        <th>Note</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>No SO</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Tikor User Salah</th>
                        <th>Note</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>ini noso</td>
                          <td>ini sid</td>
                          <td>ini alamat</td>
                          <td>ini tikor salah</td>
                          <td>ini note</td>
                          <td><a href="#" class="btn btn-warning btn-sm"><i class="fas fa-pen"></i></a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <section class="col-lg-6">
              <!-- Custom tabs (Charts with tabs)-->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-check-circle mr-1"></i>
                    Done
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content p-0">
                    <table id="tableDone" class="table table-bordered table-striped table-sm">
                      <thead>
                        <th>No</th>
                        <th>No SO</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Tikor User Salah</th>
                        <th>Note</th>
                        <th>Tikor User Baru</th>
                        <th>Aksi</th>
                      </thead>
                      <tfoot>
                        <th>No</th>
                        <th>No SO</th>
                        <th>SID</th>
                        <th>Alamat</th>
                        <th>Tikor User Salah</th>
                        <th>Note</th>
                        <th>Tikor User Baru</th>
                        <th>Aksi</th>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>ini noso</td>
                          <td>ini sid</td>
                          <td>ini alamat</td>
                          <td>ini tikor salah</td>
                          <td>ini note</td>
                          <td>ini tikor baru</td>
                          <td><a href="#" class="btn btn-warning btn-sm"><i class="fas fa-pen"></i></a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div><!-- /.card-body -->
              </div>
              <!-- /.card -->
            </section>
            <!-- /.Left col -->
          </div>
          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>

    <?php
    require('../required/footer.php');
    ?>

    <!-- Modal -->
    <div class="modal fade" id="formTikor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="container-fluid">
              <div class="row">
                <div class="col-12">
                  <div class="form-group">
                    <label for="noSo">No SO</label>
                    <input type="text" name="noso" id="noSo" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="sid">SID</label>
                    <input type="text" name="sid" id="sid" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" name="alamat" id="alamat" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="tikorUsersalah">Tikor User Salah</label>
                    <input type="text" name="tikorusersalah" id="tikorUsersalah" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for="note">Note</label>
                    <input type="text" name="note" id="note" class="form-control">
                  </div>
                </div>
              </div>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../assets/page-system/dist/js/adminlte.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../assets/page-system/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
  <!-- DataTables & Plugins -->
  <script src="../assets/page-system/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../assets/page-system/plugins/jszip/jszip.min.js"></script>
  <script src="../assets/page-system/plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../assets/page-system/plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <script>
    $(function() {
      $("#tableProses").DataTable({
        "responsive": true,
        "autoWidth": false,
        "buttons": ["excel", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    $(function() {
      $("#tableDone").DataTable({
        "responsive": true,
        "autoWidth": false,
        "buttons": ["excel", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });
  </script>
</body>

</html>