<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../assets/page-system/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="../assets/page-system/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../assets/page-system/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="../assets/page-system/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../assets/page-system/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="../assets/page-system/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="../assets/page-system/plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="../assets/page-system/plugins/summernote/summernote-bs4.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../assets/page-system/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/page-system/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/page-system/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <?php
        require('../required/header-admin.php');
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Akun Manager</h1>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Left col -->
                        <section class="col-lg-12">
                            <!-- Custom tabs (Charts with tabs)-->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-user mr-1"></i> User
                                        <div class="justify-content-end">
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalNewakun"><i class="fas fa-plus"></i>
                                                Tambah Akun Baru</button>
                                            <!--MODAL ADD NEW AKUN-->
                                            <div class="modal fade" id="modalNewakun" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLongTitle">Tambah Akun Baru</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="container-fluid">
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <form action="proses.php" method="post" id="form-tambahakun">
                                                                            <div class="form-group">
                                                                                <label for="nama">Nama Lengkap</label>
                                                                                <input type="text" name="nama" id="nama" class="form-control form-control-sm" required>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="bidang">Bidang</label>
                                                                                <select name="bidang" id="bidang" class="custom-select custom-select-sm">
                                                                                    <optgroup label="---Pilih---">
                                                                                        <option value="SBU Jakarta">SBU Jakarta</option>
                                                                                        <option value="Retail Solution">Retail Solution</option>
                                                                                    </optgroup>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="role">Role</label>
                                                                                <select name="role" id="role" class="custom-select custom-select-sm" required>
                                                                                    <optgroup label="---Pilih---">
                                                                                        <option value="admin">Admin</option>
                                                                                        <option value="user">User</option>
                                                                                        <option value="cc">Customer Care</option>
                                                                                    </optgroup>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="username">Username</label>
                                                                                <input type="text" name="username" id="username" class="form-control form-control-sm" required>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for="password">Password</label>
                                                                                <input type="password" name="password" id="password" class="form-control form-control-sm" required>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <div>
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary" form="form-tambahakun" name="account_add">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </h3>
                                </div><!-- /.card-header -->
                                <div class="card-body">
                                    <div class="tab-content p-0">
                                        <table id="listakun" class="table table-sm table-bordered table-striped table-sm">
                                            <thead>
                                                <th>No</th>
                                                <th>Nama Lengkap</th>
                                                <th>Bidang</th>
                                                <th>Role</th>
                                                <th>Aksi</th>
                                            </thead>
                                            <tfoot>
                                                <th>No</th>
                                                <th>Nama Lengkap</th>
                                                <th>Bidang</th>
                                                <th>Role</th>
                                                <th>Aksi</th>
                                            </tfoot>
                                            <tbody>
                                                <?php
                                                $q_akun = mysqli_query($connect, "SELECT * FROM account ORDER BY role");
                                                $no_akun = 1;
                                                while ($data = mysqli_fetch_array($q_akun)) {
                                                ?>
                                                    <tr>
                                                        <td><?= $no_akun ?></td>
                                                        <td><?= $data['nama'] ?></td>
                                                        <td><?= $data['bidang'] ?></td>
                                                        <td><?= $data['role'] ?></td>
                                                        <td>
                                                            <button type="button" data-toggle="modal" data-target="#akun<?= $data['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-pen"></i> Details</button>
                                                        </td>
                                                    </tr>
                                                    <!-- Modal Details-->
                                                    <div class="modal fade" id="akun<?= $data['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLongTitle">Detail Akun <?= $data['nama'] ?></h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="container-fluid">
                                                                        <div class="row">
                                                                            <div class="col-12">
                                                                                <form action="proses.php" id="form-editakun<?= $data['id'] ?>" method="post">
                                                                                    <div class="form-group">
                                                                                        <label for="nama">Nama Lengkap</label>
                                                                                        <input type="text" name="nama" id="nama" class="form-control form-control-sm" value="<?= $data['nama'] ?>">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="bidang">Bidang</label>
                                                                                        <select name="bidang" id="bidang" class="custom-select custom-select-sm">
                                                                                            <optgroup label="---Pilih---">
                                                                                                <option value="SBU Jakarta" selected>SBU Jakarta</option>
                                                                                                <option value="Retail Solution">Retail Solution</option>
                                                                                            </optgroup>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="role">Role</label>
                                                                                        <select name="role" id="role" class="custom-select custom-select-sm">
                                                                                            <optgroup label="---Pilih---">
                                                                                                <option value="admin" selected>Admin</option>
                                                                                                <option value="user">User</option>
                                                                                                <option value="cc">Customer Care</option>
                                                                                            </optgroup>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="username">Username</label>
                                                                                        <input type="text" name="username" id="username" class="form-control form-control-sm" value="<?= $data['username'] ?>">
                                                                                        <input type="text" name="username_old" value="<?= $data['username'] ?>" hidden>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="password">Password</label>
                                                                                        <input type="password" name="password" id="password" class="form-control form-control-sm" value="<?= $data['password'] ?>">
                                                                                    </div>
                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer justify-content-between">
                                                                    <div>
                                                                        <button type="submit" class="btn btn-danger" form="form-editakun<?= $data['id'] ?>" name="account_delete">Delete</button>
                                                                    </div>
                                                                    <div>
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                        <button type="submit" class="btn btn-warning" form="form-editakun<?= $data['id'] ?>" name="account_update">Update</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php
                                                    $no_akun++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </section>
                        <!-- /.Left col -->
                    </div>
                    <!-- /.row (main row) -->
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>

        <?php
        require('../required/footer.php');
        ?>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../assets/page-system/plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="../assets/page-system/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="../assets/page-system/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="../assets/page-system/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="../assets/page-system/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="../assets/page-system/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../assets/page-system/dist/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../assets/page-system/dist/js/demo.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="../assets/page-system/dist/js/pages/dashboard.js"></script>
    <!-- DataTables & Plugins -->
    <script src="../assets/page-system/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="../assets/page-system/plugins/jszip/jszip.min.js"></script>
    <script src="../assets/page-system/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="../assets/page-system/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="../assets/page-system/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script>
        $(function() {
            $("#listakun").DataTable({
                "responsive": true,
                "autoWidth": false
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        });
    </script>
</body>

</html>